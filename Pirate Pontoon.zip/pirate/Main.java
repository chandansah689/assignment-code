package pontoon;


//Main class starts a new instance of the game
public class Main {
    public static void main(String[] args) {
    	//Print game title
        System.out.println("Pirate Pontoon");
       //'pontoon' is the new instance of Game()
        Game pontoon = new Game();}
}
